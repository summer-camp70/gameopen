const express = require('express');
const session = require('express-session');
const helmet = require('helmet');
const bcrypt = require('bcryptjs');
const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

// Load local .env settings before the app reads process.env. Existing shell
// environment variables take priority over values in the file.
const envFile = path.join(__dirname, '.env');
if (fs.existsSync(envFile)) {
  for (const line of fs.readFileSync(envFile, 'utf8').replace(/\\n/g, '\n').split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith('#')) continue;
    const separator = trimmed.indexOf('=');
    if (separator < 1) continue;
    const key = trimmed.slice(0, separator).trim();
    let value = trimmed.slice(separator + 1).trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) {
      value = value.slice(1, -1);
    }
    if (!(key in process.env)) process.env[key] = value;
  }
}

const app = express();
const PORT = Number(process.env.PORT || 3000);
if (!process.env.ADMIN_USERNAME || !process.env.ADMIN_PASSWORD) {
  console.error('Director login is not configured. Check ADMIN_USERNAME and ADMIN_PASSWORD in the .env file.');
} else {
  console.log('Director login configuration loaded.');
}
const DATA_DIR = path.join(__dirname, 'data');
fs.mkdirSync(DATA_DIR, { recursive: true });
const db = new Database(path.join(DATA_DIR, 'driftwood.db'));
db.pragma('journal_mode = WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS parents (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 name TEXT NOT NULL,
 phone TEXT NOT NULL,
 email TEXT NOT NULL UNIQUE,
 password_hash TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS campers (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 parent_id INTEGER NOT NULL REFERENCES parents(id) ON DELETE CASCADE,
 child_name TEXT NOT NULL,
 age INTEGER NOT NULL CHECK(age BETWEEN 8 AND 12),
 program TEXT NOT NULL,
 session_choice TEXT NOT NULL,
 emergency_contact TEXT NOT NULL,
 payment_method TEXT NOT NULL,
 transport TEXT NOT NULL,
 pickup_area TEXT DEFAULT '',
 notes TEXT DEFAULT '',
 status TEXT NOT NULL DEFAULT 'Received',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS activity_updates (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 camper_id INTEGER NOT NULL REFERENCES campers(id) ON DELETE CASCADE,
 activity_date TEXT NOT NULL,
 activity TEXT NOT NULL,
 note TEXT NOT NULL DEFAULT '',
 attendance TEXT NOT NULL DEFAULT 'Update',
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS camper_agreements (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 camper_id INTEGER NOT NULL REFERENCES campers(id) ON DELETE CASCADE,
 agreement_key TEXT NOT NULL,
 agreement_title TEXT NOT NULL,
 agreement_text TEXT NOT NULL,
 signature TEXT NOT NULL DEFAULT '',
 signed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 UNIQUE(camper_id, agreement_key)
);
`);
const camperColumns = db.prepare('PRAGMA table_info(campers)').all().map(c => c.name);
const migrations = [
  ['parent_signature', "TEXT NOT NULL DEFAULT ''"],
  ['parent_signed_at', "TEXT NOT NULL DEFAULT ''"],
  ['director_name', "TEXT NOT NULL DEFAULT ''"],
  ['director_signature', "TEXT NOT NULL DEFAULT ''"],
  ['director_signed_at', "TEXT NOT NULL DEFAULT ''"],
  ['director_status', "TEXT NOT NULL DEFAULT 'Pending review'"],
  ['payment_status', "TEXT NOT NULL DEFAULT 'Not recorded'"],
  ['amount_received', "TEXT NOT NULL DEFAULT ''"],
  ['payment_reference', "TEXT NOT NULL DEFAULT ''"],
  ['payment_screenshot', "TEXT NOT NULL DEFAULT ''"],
  ['director_notes', "TEXT NOT NULL DEFAULT ''"]
];
for (const [column, definition] of migrations) {
  if (!camperColumns.includes(column)) db.exec(`ALTER TABLE campers ADD COLUMN ${column} ${definition}`);
}
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.urlencoded({ extended: false, limit: '4mb' }));
app.use(express.json({ limit: '30kb' }));
app.use(session({
 secret: process.env.SESSION_SECRET || 'local-development-change-this-secret',
 resave: false, saveUninitialized: false,
 cookie: { httpOnly: true, sameSite: 'lax', secure: process.env.NODE_ENV === 'production', maxAge: 1000 * 60 * 60 * 8 }
}));


// Telegram notifications intentionally contain only a registration reference,
// event type, and operational payment status. Never transmit child/parent details,
// signatures, notes, or receipt images to Telegram.
async function notifyDirectorTelegram(message) {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID;
  if (!token || !chatId) return;
  try {
    const response = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ chat_id: chatId, text: message, disable_web_page_preview: true })
    });
    if (!response.ok) console.error('Telegram notification failed:', response.status);
  } catch (error) {
    console.error('Telegram notification unavailable:', error.message);
  }
}

const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function validSignature(value) {
  return typeof value === 'string' && value.length <= 250000 && /^data:image\/png;base64,[A-Za-z0-9+/=]+$/.test(value);
}
const signaturePad = (id, hiddenName, label) => `<div class="field full"><label>${label} *</label><div class="signature-wrap"><canvas id="${id}" width="700" height="180" aria-label="${label} drawing area"></canvas></div><input type="hidden" name="${hiddenName}" id="${hiddenName}"><div class="row"><button class="btn light" type="button" onclick="clearSignature('${id}','${hiddenName}')">Clear signature</button><span class="small muted">Sign using a mouse, touch screen, or stylus.</span></div></div>`;
const signatureScript = `<script>
function setupSignature(canvasId,hiddenId){const c=document.getElementById(canvasId),h=document.getElementById(hiddenId);if(!c||!h)return;const ctx=c.getContext('2d');ctx.lineWidth=3;ctx.lineCap='round';ctx.strokeStyle='#20352a';let drawing=false,dirty=false;function pos(e){const r=c.getBoundingClientRect();const p=e.touches?e.touches[0]:e;return {x:(p.clientX-r.left)*c.width/r.width,y:(p.clientY-r.top)*c.height/r.height}}function start(e){e.preventDefault();drawing=true;const p=pos(e);ctx.beginPath();ctx.moveTo(p.x,p.y)}function move(e){if(!drawing)return;e.preventDefault();const p=pos(e);ctx.lineTo(p.x,p.y);ctx.stroke();dirty=true;h.value=dirty?c.toDataURL('image/png'):''}function end(){drawing=false;if(dirty)h.value=c.toDataURL('image/png')}c.addEventListener('pointerdown',start);c.addEventListener('pointermove',move);window.addEventListener('pointerup',end);c.addEventListener('touchstart',start,{passive:false});c.addEventListener('touchmove',move,{passive:false});window.addEventListener('touchend',end);c.dataset.clear='';}
function clearSignature(canvasId,hiddenId){const c=document.getElementById(canvasId),h=document.getElementById(hiddenId);if(c)c.getContext('2d').clearRect(0,0,c.width,c.height);if(h)h.value='';if(c)c.dataset.clear='yes';}
</script>`;
const page = (title, body, user=null) => `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#214f3b"><title>${esc(title)} | Driftwood Camp</title><style>
:root{--green:#214f3b;--gold:#e6b85c;--paper:#f6f3e9;--ink:#20352a;--muted:#637166}*{box-sizing:border-box}body{margin:0;background:var(--paper);color:var(--ink);font:16px/1.6 system-ui,-apple-system,"Segoe UI",sans-serif}header{background:var(--green);color:white;padding:16px max(20px,calc((100% - 1100px)/2));display:flex;justify-content:space-between;align-items:center;gap:16px;flex-wrap:wrap}header a{color:white;text-decoration:none;margin-right:14px}.brand{font-weight:900;letter-spacing:.08em}.mark{color:var(--gold)}main{max-width:1100px;margin:auto;padding:28px 20px 60px}.hero{background:var(--green);color:white;padding:38px 24px;border-radius:22px;margin:20px auto}.hero p{color:#e2eae3;max-width:760px}.eyebrow{color:#9d7130;font-size:.78rem;font-weight:900;letter-spacing:.15em;text-transform:uppercase}.hero .eyebrow{color:var(--gold)}h1,h2,h3{line-height:1.15}h1{font-size:clamp(2.2rem,6vw,4rem);margin:.4em 0}h2{font-size:1.7rem}.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:18px}.card{background:#fffdf7;border:1px solid #dfe4da;border-radius:18px;padding:22px;margin:16px 0}.btn,button{display:inline-block;background:var(--gold);color:#1d2b22;padding:11px 17px;border:0;border-radius:999px;font-weight:800;text-decoration:none;cursor:pointer;font:inherit}.btn.dark{background:var(--green);color:white}.btn.light{background:transparent;border:1px solid #9bac9e;color:var(--green)}.actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:20px}.field{display:flex;flex-direction:column;gap:5px;margin:12px 0}label{font-weight:750}input,select,textarea{width:100%;padding:12px;border:1px solid #cbd5c9;border-radius:10px;font:inherit;background:white;color:#20352a}input:focus,select:focus,textarea:focus{outline:3px solid #e6b85c77}.formgrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:0 16px}.full{grid-column:1/-1}.muted{color:var(--muted)}.notice{padding:12px 15px;border-radius:12px;background:#e5f1e3;margin:14px 0}.warn{padding:12px 15px;border-radius:12px;background:#fff0d2;color:#6d4a11}.pill{display:inline-block;background:#e7ecdf;border-radius:999px;padding:5px 10px;margin:3px;font-size:.86rem}.price{font-size:2.7rem;color:var(--green);font-weight:900}.row{display:flex;gap:12px;flex-wrap:wrap;align-items:center}.activity{border-left:4px solid var(--gold);padding:8px 14px;margin:12px 0;background:#f9f6ed}.small{font-size:.86rem}.signature-wrap{border:1px dashed #8da998;border-radius:12px;background:#fff;padding:6px;max-width:100%;touch-action:none}.signature-wrap canvas{display:block;width:100%;height:150px;touch-action:none;cursor:crosshair}.signature-img{max-width:100%;max-height:100px;border:1px solid #dfe4da;border-radius:8px;background:white;padding:5px}.status-select{max-width:100%;padding:9px;border-radius:8px}footer{background:#183b2b;color:#dbe7dc;padding:24px max(20px,calc((100% - 1100px)/2));display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap}table{width:100%;border-collapse:collapse}td,th{text-align:left;padding:9px;border-bottom:1px solid #dfe4da}@media(max-width:600px){header{align-items:flex-start}main{padding:18px 14px 40px}.card{padding:17px}.full{grid-column:auto}}
</style></head><body><header><div class="brand"><span class="mark">✦</span> DRIFTWOOD CAMP</div><nav><a href="/">Home</a><a href="/#activities">Activities</a><a href="/map">Map</a>${user?'<a href="/dashboard">Parent portal</a><a href="/logout">Log out</a>':'<a href="/register">Register</a><a href="/login">Parent login</a>'}<a href="/director">Director portal</a></nav></header><main>${body}</main><footer><div><strong>DRIFTWOOD CAMP</strong><br>Outdoor learning. Lasting confidence.</div><div>Addis Ababa, Ethiopia · Ages 8–12</div><div>1,000 ETB · Maximum 40 children</div></footer></body></html>`;

function requireAuth(req,res,next){ if(!req.session.parentId) return res.redirect('/login'); next(); }
function notice(text){return `<div class="notice">${esc(text)}</div>`;}
app.get('/',(req,res)=>res.send(page('Outdoor adventures',`
<section class="hero"><div class="eyebrow">Adventure · Friendship · Growth</div><h1>Big adventures. Brave young minds.</h1><p>An outdoor camp in Addis Ababa for children ages 8–12. Campers build practical skills, explore nature, move to music, and discover teamwork in a supervised group setting.</p><div class="actions"><a class="btn" href="/register">Register a child</a><a class="btn" href="/map">View camp map</a></div><p><span class="pill">Saturday & Sunday</span><span class="pill">Summer program: 2 months</span><span class="pill">Maximum 40 children</span></p></section>
<div class="grid"><section class="card"><div class="eyebrow">Camp fee</div><div class="price">1,000 ETB</div><p class="muted">Confirm whether the fee applies per day, weekend, or another session before payment.</p></section><section class="card"><div class="eyebrow">Camp location</div><h2>Gulele Botanic Garden</h2><p class="muted">The preferred location. Confirm venue permission and the exact meeting point with the organizer.</p><a class="btn dark" href="/map">Open map</a></section></div>
<section class="card" id="activities"><div class="eyebrow">Activities</div><h2>Skills for the outdoors—and for life</h2><div class="grid"><div><h3>🧭 Wilderness skills</h3><p>Knot tying, shelter building, compass basics and outdoor safety.</p></div><div><h3>🌿 Nature & hiking</h3><p>Guided nature observation and supervised trail activities.</p></div><div><h3>🎵 Music & creativity</h3><p>Dance, camp songs, storytelling, skits and nature crafts.</p></div><div><h3>🏅 Games & teamwork</h3><p>Relays, obstacle challenges, team games and the Driftwood Olympia.</p></div></div></section>
<section class="card"><div class="eyebrow">Sample day</div><h2>8:00 AM – 4:00 PM</h2><table><tr><th>Time</th><th>Activity</th></tr><tr><td>8:00–8:30</td><td>Arrival, parent sign-in, safety check</td></tr><tr><td>8:30–9:15</td><td>Dance and warm-up</td></tr><tr><td>9:15–10:45</td><td>Wilderness skills workshop</td></tr><tr><td>10:45–12:15</td><td>Nature trail and navigation</td></tr><tr><td>12:15–1:15</td><td>Picnic lunch and rest</td></tr><tr><td>1:15–3:00</td><td>Team games and Olympia practice</td></tr><tr><td>3:00–4:00</td><td>Reflection, awards and parent checkout</td></tr></table></section>
<section class="card"><h2>For parents and guardians</h2><p>Register your child, request transport, and sign in to view registration details and organizer-posted activity updates.</p><div class="actions"><a class="btn dark" href="/register">Register</a><a class="btn light" href="/login">Parent login</a></div></section>
`)));
app.get('/map',(req,res)=>res.send(page('Camp map',`<section class="card"><div class="eyebrow">Only preferred venue</div><h1>Gulele Botanic Garden</h1><p>Use the external map search to plan your trip. It does not confirm camp booking, permission, access, or the exact meeting point.</p><div class="actions"><a class="btn dark" href="https://www.google.com/maps/search/?api=1&query=Gulele+Botanic+Garden+Addis+Ababa" target="_blank" rel="noopener noreferrer">Open Google Maps</a><a class="btn light" href="/register">Request transportation</a></div><div class="warn">Transport routes, pickup points, schedule, availability and any extra fee must be confirmed by the camp organizer.</div></section>` ,req.session.parentId?{id:req.session.parentId}:null)));
app.get('/register',(req,res)=>res.send(page('Register a child',`<section class="card"><div class="eyebrow">Family registration</div><h1>Register a camper</h1><p class="muted">Create a parent account and submit a registration. Your details will be saved in the local database on this server.</p><form method="post" action="/register"><div class="formgrid"><div class="field"><label>Parent / guardian full name *</label><input name="parentName" required maxlength="100" autocomplete="name"></div><div class="field"><label>Phone number *</label><input name="phone" required maxlength="40" inputmode="tel"></div><div class="field"><label>Email *</label><input type="email" name="email" required maxlength="254" autocomplete="email"></div><div class="field"><label>Create password *</label><input type="password" name="password" required minlength="10" autocomplete="new-password"><span class="small muted">Use at least 10 characters.</span></div><div class="field"><label>Emergency contact name and phone *</label><input name="emergency" required maxlength="120"></div><div class="field"><label>Child full name *</label><input name="childName" required maxlength="100"></div><div class="field"><label>Child age *</label><select name="age" required><option value="">Select age</option>${[8,9,10,11,12].map(a=>`<option value="${a}">${a}</option>`).join('')}</select></div><div class="field"><label>Program *</label><select name="program" required><option value="Weekend camp">Weekend camp</option><option value="Summer camp (two months)">Summer camp (two months)</option></select></div><div class="field"><label>Preferred attendance *</label><select name="sessionChoice" required><option>Saturday</option><option>Sunday</option><option>Both Saturday and Sunday</option><option>Summer program — dates to be confirmed</option></select></div><div class="field full"><div class="card"><div class="eyebrow">Camp payment accounts</div><h3>Pay using one of these methods</h3><p><strong>Dashen Bank</strong><br>Account number: <strong>5516105727021</strong></p><p><strong>Telebirr</strong><br>Phone number: <strong>0935347799</strong></p><p class="muted small">Please verify the account name with the camp organizer before sending money. Keep your receipt. Never share your PIN or OTP.</p></div></div><div class="field"><label>Preferred payment method *</label><select name="paymentMethod" required><option value="Dashen Bank">Dashen Bank</option><option value="Telebirr">Telebirr</option><option value="Cash">Cash — arrange with organizer</option></select></div><div class="field"><label>Payment receipt screenshot (optional)</label><input type="file" id="paymentReceiptFile" accept="image/png,image/jpeg,image/webp"><input type="hidden" name="paymentScreenshot" id="paymentScreenshot"><span class="small muted">Upload a screenshot of the successful transfer. Maximum 2 MB. Hide unrelated personal information first.</span><img id="paymentReceiptPreview" class="signature-img" alt="Payment receipt preview" hidden></div><div class="field"><label>Need transportation? *</label><select name="transport" required><option>Yes — need transportation</option><option>No — own drop-off and pickup</option></select></div><div class="field"><label>Pickup area / meeting point</label><input name="pickupArea" maxlength="160" placeholder="Area only, if transport is needed"></div><div class="field full"><label>Notes for organizer (optional)</label><textarea name="notes" rows="3" maxlength="1000"></textarea></div></div><div class="line"></div><div class="eyebrow">4 · Read and sign each agreement</div><p class="muted">Each required agreement has its own checkbox and signature. These are draft templates; have them reviewed locally before public use.</p>
<div class="card"><h3>Agreement 1 · Participation consent</h3><p>I confirm that I am the parent/legal guardian and authorize the child named above to participate in Driftwood Camp’s supervised outdoor activities, including nature walks, hiking, outdoor skills, physical games, music and dance. I understand the organizer will provide final dates, rules, venue and supervision information.</p><div class="field"><label><input type="checkbox" name="consentParticipation" value="yes" required style="width:auto"> I have read and agree to the participation consent. *</label></div>${signaturePad('participationSignaturePad','participationSignature','Parent / guardian signature for participation consent')}</div>
<div class="card"><h3>Agreement 2 · Outdoor activity risk acknowledgment</h3><p>I understand that outdoor activities and physical games may involve ordinary risks such as uneven ground, weather, falls, or minor injuries. I will discuss relevant concerns with the organizer and understand that staff should explain activity rules and safety precautions. This acknowledgment does not waive any rights that cannot legally be waived.</p><div class="field"><label><input type="checkbox" name="consentRisks" value="yes" required style="width:auto"> I have read and acknowledge the activity-risk information. *</label></div>${signaturePad('riskSignaturePad','riskSignature','Parent / guardian signature for risk acknowledgment')}</div>
<div class="card"><h3>Agreement 3 · Emergency care authorization</h3><p>If my child becomes ill or is injured, I authorize camp staff to contact me and, when reasonably necessary, contact emergency services or arrange urgent medical assistance. I understand staff should make reasonable efforts to reach the listed emergency contact.</p><div class="field"><label><input type="checkbox" name="consentEmergency" value="yes" required style="width:auto"> I have read and agree to the emergency-care authorization. *</label></div>${signaturePad('emergencySignaturePad','emergencySignature','Parent / guardian signature for emergency-care authorization')}</div>
<div class="card"><h3>Optional · Photo and video permission</h3><p>Choose whether the camp may use photos or video of your child for camp updates or promotional materials. This choice is optional and should not affect participation. Final wording should match the actual intended use.</p><div class="field"><label for="mediaConsent">Photo/video preference</label><select name="mediaConsent" id="mediaConsent" required><option value="No permission granted">Do not grant photo/video permission</option><option value="Permission granted">I grant photo/video permission</option></select></div>${signaturePad('mediaSignaturePad','mediaSignature','Parent / guardian signature confirming photo/video choice')}</div>
<p class="muted small">Venue: Gulele Botanic Garden, Addis Ababa. Fee shown on the website is 1,000 ETB; confirm the fee basis, dates, transport and payment instructions before paying.</p><div class="warn">Do not enter passwords, PINs, OTPs, or bank/card details in notes. Only an authorized parent/guardian should create an account.</div><div class="actions"><button type="submit">Create account & register</button><a class="btn light" href="/login">Already registered? Log in</a></div></form>${signatureScript}<script>['participation','risk','emergency','media'].forEach(k=>setupSignature(k+'SignaturePad',k+'Signature'));const receiptFile=document.getElementById('paymentReceiptFile'),receiptData=document.getElementById('paymentScreenshot'),receiptPreview=document.getElementById('paymentReceiptPreview');receiptFile.addEventListener('change',function(){const f=this.files&&this.files[0];receiptData.value='';receiptPreview.hidden=true;if(!f)return;if(!['image/png','image/jpeg','image/webp'].includes(f.type)||f.size>2*1024*1024){this.value='';alert('Choose a PNG, JPG, or WEBP image under 2 MB.');return;}const reader=new FileReader();reader.onload=()=>{receiptData.value=String(reader.result||'');receiptPreview.src=receiptData.value;receiptPreview.hidden=false;};reader.readAsDataURL(f);});document.querySelector('form[action=\"/register\"]').addEventListener('submit',function(e){const required=['participationSignature','riskSignature','emergencySignature'];if(required.some(id=>!document.getElementById(id).value)||(document.getElementById('mediaConsent').value==='Permission granted'&&!document.getElementById('mediaSignature').value)){e.preventDefault();alert('Please sign all required agreements. If you grant photo/video permission, sign that choice too.');}});</script></section>`)));
app.post('/register', async (req,res)=>{
  const b=req.body;
  const parentName=String(b.parentName||'').trim(), phone=String(b.phone||'').trim(), email=String(b.email||'').trim().toLowerCase(), password=String(b.password||'');
  const childName=String(b.childName||'').trim(), age=Number(b.age), emergency=String(b.emergency||'').trim();
  const paymentScreenshot=String(b.paymentScreenshot||'');
  const validPaymentScreenshot=!paymentScreenshot || (paymentScreenshot.length<=2800000 && /^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(paymentScreenshot));
  if(!parentName||!phone||!email||password.length<10||!childName||!Number.isInteger(age)||age<8||age>12||!emergency||!validPaymentScreenshot) return res.status(400).send(page('Check registration',`<section class="card"><h1>Please check the form</h1><p>Required fields must be completed, age must be 8–12, and password must have at least 10 characters.</p><a class="btn" href="/register">Back to form</a></section>`));
  try{
    const hash=await bcrypt.hash(password,12);
    const info=db.prepare('INSERT INTO parents(name,phone,email,password_hash) VALUES(?,?,?,?)').run(parentName,phone,email,hash);
    const agreements=[
      {key:'participation',title:'Participation consent',field:'participationSignature',check:'consentParticipation',text:'Parent/guardian authorized supervised camp participation and acknowledged that final dates, rules, venue and supervision information will be provided.'},
      {key:'risk',title:'Outdoor activity risk acknowledgment',field:'riskSignature',check:'consentRisks',text:'Parent/guardian acknowledged ordinary outdoor activity risks and safety precautions; this does not waive rights that cannot legally be waived.'},
      {key:'emergency',title:'Emergency care authorization',field:'emergencySignature',check:'consentEmergency',text:'Parent/guardian authorized staff to contact them and, when reasonably necessary, emergency services or urgent medical assistance.'}
    ];
    const signedAgreements=agreements.map(a=>({...a,signature:String(b[a.field]||'')}));
    const mediaConsent=String(b.mediaConsent||'No permission granted');
    const mediaSignature=String(b.mediaSignature||'');
    if(signedAgreements.some(a=>b[a.check]!=='yes'||!validSignature(a.signature)) || !['No permission granted','Permission granted'].includes(mediaConsent) || (mediaConsent==='Permission granted'&&!validSignature(mediaSignature))) {
      db.prepare('DELETE FROM parents WHERE id=?').run(info.lastInsertRowid);
      return res.status(400).send(page('Agreements required',`<section class=\"card\"><h1>Please complete the agreements</h1><p>Accept and sign all three required agreements. If you grant photo/video permission, sign that optional choice as well.</p><a class=\"btn\" href=\"/register\">Back to registration</a></section>`));
    }
    const parentSignature=signedAgreements[0].signature;
    const result=db.prepare(`INSERT INTO campers(parent_id,child_name,age,program,session_choice,emergency_contact,payment_method,transport,pickup_area,notes,parent_signature,parent_signed_at,payment_screenshot) VALUES(?,?,?,?,?,?,?,?,?,?,?,CURRENT_TIMESTAMP,?)`).run(info.lastInsertRowid,childName,age,String(b.program||'Weekend camp'),String(b.sessionChoice||'Saturday'),emergency,String(b.paymentMethod||''),String(b.transport||''),String(b.pickupArea||'').trim(),String(b.notes||'').trim(),parentSignature,paymentScreenshot);
    const camperId=Number(result.lastInsertRowid);
    // Keep the first 40 non-waitlisted registrations within capacity; later entries enter the waiting list.
    const activeCount=db.prepare("SELECT COUNT(*) AS n FROM campers WHERE director_status!='Waiting list'").get().n;
    if(activeCount>40) db.prepare("UPDATE campers SET director_status='Waiting list' WHERE id=?").run(camperId);
    const insertAgreement=db.prepare('INSERT INTO camper_agreements(camper_id,agreement_key,agreement_title,agreement_text,signature) VALUES(?,?,?,?,?)');
    for(const a of signedAgreements) insertAgreement.run(camperId,a.key,a.title,a.text,a.signature);
    if(mediaConsent==='Permission granted') insertAgreement.run(camperId,'media','Photo and video permission','Parent/guardian granted photo/video permission for camp updates or promotional materials.',mediaSignature);
    else insertAgreement.run(camperId,'media_declined','Photo and video permission','Parent/guardian did not grant photo/video permission.','');
    void notifyDirectorTelegram(`Driftwood Camp: new registration received. Reference #${camperId}. Receipt image: ${paymentScreenshot ? 'uploaded (view securely in Director Portal)' : 'not uploaded'}. Submitted: ${new Date().toISOString()}. No personal details or files are sent in this alert.`);
    req.session.parentId=Number(info.lastInsertRowid);
    req.session.parentName=parentName;
    res.redirect('/dashboard?registered=1');
  }catch(e){
    if(String(e.message).includes('UNIQUE')) return res.status(409).send(page('Account exists',`<section class="card"><h1>Email already registered</h1><p>An account with this email already exists. Log in to view your registration.</p><a class="btn" href="/login">Parent login</a></section>`));
    console.error(e); res.status(500).send(page('Registration error',`<section class="card"><h1>Could not save registration</h1><p>Please try again.</p><a class="btn" href="/register">Back</a></section>`));
  }
});
app.get('/login',(req,res)=>res.send(page('Parent login',`<section class="card" style="max-width:620px;margin:auto"><div class="eyebrow">Returning families</div><h1>Parent login</h1><p class="muted">Sign in with the email and password used when registering.</p>${req.query.error?'<div class="warn">Email or password was not recognized.</div>':''}<form method="post" action="/login"><div class="field"><label>Email</label><input type="email" name="email" required autocomplete="username"></div><div class="field"><label>Password</label><input type="password" name="password" required autocomplete="current-password"></div><button type="submit">Log in</button></form><p class="muted small">This local starter has no email-based password reset. Keep your password safe.</p></section>`)));
app.post('/login',async(req,res)=>{
  const email=String(req.body.email||'').trim().toLowerCase(), password=String(req.body.password||'');
  const parent=db.prepare('SELECT * FROM parents WHERE email=?').get(email);
  if(!parent||!(await bcrypt.compare(password,parent.password_hash))) return res.redirect('/login?error=1');
  req.session.regenerate(err=>{if(err)return res.status(500).send('Session error');req.session.parentId=parent.id;req.session.parentName=parent.name;res.redirect('/dashboard');});
});
app.get('/dashboard',requireAuth,(req,res)=>{
  const parent=db.prepare('SELECT id,name,email,phone,created_at FROM parents WHERE id=?').get(req.session.parentId);
  const campers=db.prepare('SELECT * FROM campers WHERE parent_id=? ORDER BY id DESC').all(parent.id);
  const content=campers.map(c=>{
    const updates=db.prepare('SELECT * FROM activity_updates WHERE camper_id=? ORDER BY activity_date DESC,id DESC').all(c.id);
    const agreements=db.prepare('SELECT * FROM camper_agreements WHERE camper_id=? ORDER BY id').all(c.id);
    const agreementHtml=agreements.length?`<div class=\"line\"></div><h3>Signed agreements</h3>${agreements.map(a=>`<div class=\"activity\"><strong>${esc(a.agreement_title)}</strong><p>${esc(a.agreement_text)}</p><br><span class=\"pill\">${a.agreement_key==='media_declined'?'Permission not granted':'Signed / recorded'}</span>${a.signature?`<br><img class=\"signature-img\" src=\"${a.signature}\" alt=\"${esc(a.agreement_title)} signature\">`:''}<p class=\"small muted\">${esc(a.signed_at)}</p></div>`).join('')}`:'<p class=\"muted\">No separate agreement records found for this registration.</p>';
    return `<section class=\"card\"><div class=\"eyebrow\">Camper registration #${c.id}</div><h2>${esc(c.child_name)}</h2><p><span class="pill">Age ${c.age}</span><span class="pill">${esc(c.program)}</span><span class="pill">Status: ${esc(c.status)}</span></p><div class="grid"><div><strong>Preferred attendance</strong><br>${esc(c.session_choice)}</div><div><strong>Camp location</strong><br>Gulele Botanic Garden</div><div><strong>Transportation</strong><br>${esc(c.transport)}</div><div><strong>Pickup area</strong><br>${esc(c.pickup_area||'Not provided')}</div><div><strong>Payment preference</strong><br>${esc(c.payment_method)}</div><div><strong>Payment status</strong><br>${esc(c.payment_status)}${c.amount_received?` · ${esc(c.amount_received)} ETB recorded`:``}</div><div><strong>Director review</strong><br>${esc(c.director_status)}</div><div><strong>Submitted</strong><br>${esc(c.created_at)}</div></div>${c.notes?`<p><strong>Parent notes:</strong> ${esc(c.notes)}</p>`:''}${c.director_notes?`<p><strong>Director message:</strong> ${esc(c.director_notes)}</p>`:''}${c.parent_signature?`<div class="grid"><div><strong>Parent consent signature</strong><br><img class="signature-img" src="${c.parent_signature}" alt="Parent signature"><p class="small muted">Signed: ${esc(c.parent_signed_at||'')}</p></div><div><strong>Director approval signature</strong><br>${c.director_signature?`<p>${esc(c.director_name||'Camp director')}</p><img class="signature-img" src="${c.director_signature}" alt="Director signature"><p class="small muted">Signed: ${esc(c.director_signed_at||'')}</p>`:'<p class="muted">Pending director review and signature.</p>'}</div></div>`:''}${agreementHtml}<div class="line"></div><h3>Parent activity updates</h3><p class="muted small">Organizer-entered updates only; no live GPS or video monitoring.</p>${updates.length?updates.map(u=>`<div class="activity"><strong>${esc(u.activity_date)} · ${esc(u.activity)}</strong><br><span class="pill">${esc(u.attendance)}</span><p>${esc(u.note)}</p></div>`).join(''):'<p class="muted">No activity updates have been posted yet.</p>'}</section>`;
  }).join('')||'<section class="card"><h2>No camper registrations found</h2><a class="btn" href="/register">Register a child</a></section>';
  res.send(page('Parent dashboard',`<section class="hero"><div class="eyebrow">Secure parent area</div><h1>Welcome, ${esc(parent.name)}</h1><p>View the registration details associated with your account and organizer-posted activity updates.</p><div class="actions"><a class="btn" href="/map">Camp map</a><a class="btn" href="/games">Family camp games</a></div></section><section class="card"><h2>Parent account</h2><p><strong>Email:</strong> ${esc(parent.email)}<br><strong>Phone:</strong> ${esc(parent.phone)}</p></section>${content}<section class="card"><h2>Games and activities</h2><p class="muted">Explore simple camp-themed games together at home.</p><a class="btn dark" href="/games">Open games</a></section>` ,parent));
});
app.get('/games',(req,res)=>res.send(page('Camp games',`<section class="card"><div class="eyebrow">Try together</div><h1>Driftwood Camp games</h1><p class="muted">These are simple browser games for family fun, not a replacement for supervised camp activities.</p><div class="grid"><article class="card"><h2>🧭 Nature scavenger hunt</h2><p>Find something round, something rough, a leaf on the ground, a bird sound, and three different natural colors. Observe without picking plants or disturbing wildlife.</p><button onclick="document.getElementById('hunt').hidden=false">Show checklist</button><ul id="hunt" hidden><li>Something round</li><li>Something rough</li><li>A fallen leaf</li><li>A bird sound</li><li>Three natural colors</li></ul></article><article class="card"><h2>🪢 Knot-learning challenge</h2><p>With an adult, practice a simple overhand knot using soft cord. Never put cord around a neck or body.</p><button onclick="document.getElementById('knotTip').hidden=false">Show safety tip</button><p id="knotTip" hidden>Practice seated with short cord, under adult supervision. Put all cord away afterward.</p></article><article class="card"><h2>🏅 Team memory game</h2><p>Memorize these five items, then hide the list and recall them: compass, leaf, tent, water bottle, bird.</p><button onclick="document.getElementById('memory').hidden=false">Reveal items</button><p id="memory" hidden>Compass · Leaf · Tent · Water bottle · Bird</p></article></div><p class="actions"><a class="btn dark" href="/dashboard">Back to parent portal</a></p></section>` ,req.session.parentId?{id:req.session.parentId}:null)));
app.get('/director',(req,res)=>{
  if(!req.session.organizer){
    return res.send(page('Director sign in',`<section class="card" style="max-width:620px;margin:auto"><div class="eyebrow">Director access</div><h1>Director portal</h1><p class="muted">Authorized director access is required to review registrations, record payments, and sign approval forms.</p>${req.query.error?'<div class="warn">Password not accepted, or director access is not configured.</div>':''}<form method="post" action="/director/login"><div class="field"><label>Director username</label><input name="adminUsername" required autocomplete="username"></div><div class="field"><label>Director password</label><input type="password" name="adminPassword" required autocomplete="current-password"></div><button type="submit">Sign in</button></form></section>`));
  }
  const campers=db.prepare('SELECT c.*,p.name AS parent_name,p.email AS parent_email,p.phone AS parent_phone FROM campers c JOIN parents p ON p.id=c.parent_id ORDER BY c.id DESC').all();
  const activeCount=Math.min(40,db.prepare("SELECT COUNT(*) AS n FROM campers WHERE director_status!='Waiting list'").get().n);
  const totalCount=campers.length;
  const pendingCount=campers.filter(c=>['Pending review','Needs information'].includes(c.director_status)).length;
  const approvedCount=campers.filter(c=>c.director_status==='Approved').length;
  const waitingCount=campers.filter(c=>c.director_status==='Waiting list').length;
  const paidTotal=campers.reduce((sum,c)=>sum+(Number(c.amount_received)||0),0);
  const paidCount=campers.filter(c=>c.payment_status==='Paid').length;
  const unpaidCount=campers.filter(c=>['Not recorded','Pending','Partially paid'].includes(c.payment_status)).length;
  const agreementSigned=campers.filter(c=>db.prepare("SELECT COUNT(*) AS n FROM camper_agreements WHERE camper_id=? AND agreement_key IN ('participation','risk','emergency') AND signature!=''").get(c.id).n===3).length;
  const overview=`<section class="card"><div class="eyebrow">Live registration overview</div><h2>Camp capacity, payments & agreements</h2><div class="grid"><div class="card"><strong>Children within capacity</strong><div class="price">${activeCount} / 40</div><p class="muted small">Total registrations received: ${totalCount}</p></div><div class="card"><strong>Pending registrations</strong><div class="price">${pendingCount}</div></div><div class="card"><strong>Approved registrations</strong><div class="price">${approvedCount}</div></div><div class="card"><strong>Waiting list</strong><div class="price">${waitingCount}</div></div><div class="card"><strong>Payments recorded</strong><div class="price">${paidTotal.toLocaleString('en-US')} ETB</div><p class="muted small">${paidCount} fully paid · ${unpaidCount} unpaid / partial</p></div><div class="card"><strong>Complete agreement sets</strong><div class="price">${agreementSigned} / ${totalCount}</div><p class="muted small">All 3 required parent agreements signed</p></div></div><p class="muted small">Counts are calculated from this app's SQLite database. Waiting-list registrations are excluded from the 40-child capacity count.</p><div class="actions"><a class="btn dark" href="/director/export.csv">Download registrations CSV</a></div></section>`;
  const cards=campers.map(c=>`<section class="card registration-card" data-search="${esc([c.child_name,c.parent_name,c.parent_email,c.parent_phone,c.director_status,c.payment_status,c.program].join(' ').toLowerCase())}"><div class="eyebrow">Registration #${c.id}</div><h2>${esc(c.child_name)} · age ${c.age}</h2><p><span class="pill">${esc(c.program)}</span><span class="pill">Parent: ${esc(c.parent_name)}</span><span class="pill">${esc(c.parent_phone)}</span><span class="pill">${esc(c.director_status)}</span></p><div class="grid"><div><strong>Parent email</strong><br>${esc(c.parent_email)}</div><div><strong>Preferred attendance</strong><br>${esc(c.session_choice)}</div><div><strong>Emergency contact</strong><br>${esc(c.emergency_contact)}</div><div><strong>Transport arrangement</strong><br>${esc(c.transport)}</div><div><strong>Pickup area / meeting point</strong><br>${esc(c.pickup_area||'Not provided')}</div><div><strong>Payment preference</strong><br>${esc(c.payment_method)}</div><div><strong>Payment receipt screenshot</strong><br>${c.payment_screenshot?`<a href="${c.payment_screenshot}" target="_blank" rel="noopener">View uploaded receipt</a><br><img class="signature-img" src="${c.payment_screenshot}" alt="Parent payment receipt screenshot">`:'Not uploaded'}</div><div><strong>Latest attendance check</strong><br>${(()=>{const a=db.prepare('SELECT activity_date,attendance FROM activity_updates WHERE camper_id=? ORDER BY activity_date DESC,id DESC LIMIT 1').get(c.id);return a?`${esc(a.attendance)} · ${esc(a.activity_date)}`:'Not recorded yet'})()}</div><div><strong>Parent consent</strong><br>${c.parent_signature?'Signed':'Missing'}</div></div>${(()=>{const ag=db.prepare('SELECT agreement_title,agreement_text,agreement_key,signature,signed_at FROM camper_agreements WHERE camper_id=? ORDER BY id').all(c.id);const byKey=Object.fromEntries(ag.map(a=>[a.agreement_key,a]));const required=[['participation','Participation consent'],['risk','Outdoor activity risk acknowledgment'],['emergency','Emergency care authorization']];const requiredChecks=required.map(([key,title])=>{const a=byKey[key];return `<div class="activity"><strong>${title}</strong><br><span class="pill">${a&&a.signature?'Signed':'MISSING SIGNATURE'}</span>${a&&a.signature?`<br><img class="signature-img" src="${a.signature}" alt="${title} signature"><p class="small muted">Signed at ${esc(a.signed_at)}</p>`:''}</div>`}).join('');const media=byKey.media||byKey.media_declined;const mediaHtml=`<div class="activity"><strong>Optional photo/video permission</strong><br><span class="pill">${byKey.media?'Permission granted — signed':byKey.media_declined?'Permission declined':'No choice recorded'}</span>${byKey.media&&byKey.media.signature?`<br><img class="signature-img" src="${byKey.media.signature}" alt="Photo/video permission signature">`:''}</div>`;return `<div class="line"></div><h3>Family agreement checks</h3>${requiredChecks}${mediaHtml}`})()}<form method="post" action="/director/registration/${c.id}"><div class="line"></div><div class="formgrid"><div class="field"><label>Registration decision</label><select class="status-select" name="directorStatus"><option ${c.director_status==='Pending review'?'selected':''}>Pending review</option><option ${c.director_status==='Approved'?'selected':''}>Approved</option><option ${c.director_status==='Needs information'?'selected':''}>Needs information</option><option ${c.director_status==='Waiting list'?'selected':''}>Waiting list</option><option ${c.director_status==='Declined'?'selected':''}>Declined</option></select></div><div class="field"><label>Payment status</label><select class="status-select" name="paymentStatus"><option ${c.payment_status==='Not recorded'?'selected':''}>Not recorded</option><option ${c.payment_status==='Pending'?'selected':''}>Pending</option><option ${c.payment_status==='Partially paid'?'selected':''}>Partially paid</option><option ${c.payment_status==='Paid'?'selected':''}>Paid</option><option ${c.payment_status==='Waived'?'selected':''}>Waived</option><option ${c.payment_status==='Refunded'?'selected':''}>Refunded</option></select></div><div class="field"><label>Amount received (ETB)</label><input name="amountReceived" type="number" min="0" step="0.01" value="${esc(c.amount_received)}" placeholder="Only amount actually received"></div><div class="field"><label>Payment reference (no PIN/OTP)</label><input name="paymentReference" maxlength="100" value="${esc(c.payment_reference)}" placeholder="Receipt/reference number"></div><div class="field"><label>Director full name *</label><input name="directorName" maxlength="120" required value="${esc(c.director_name)}" placeholder="Name of approving director"></div><div class="field full"><label>Director notes to parent</label><textarea name="directorNotes" maxlength="1000" rows="2">${esc(c.director_notes)}</textarea></div></div><div class="eyebrow">Director approval signature</div>${c.director_signature?`<p>Existing signature saved:</p><img class="signature-img" src="${c.director_signature}" alt="Director signature">`:'<p class="muted small">Sign below to approve this registration. The signature is saved with the decision.</p>'}<div class="field full"><label>Director signature *</label><div class="signature-wrap"><canvas id="directorSignaturePad${c.id}" width="700" height="180" aria-label="Director signature drawing area"></canvas></div><input type="hidden" name="directorSignature${c.id}" id="directorSignature${c.id}"><div class="row"><button class="btn light" type="button" onclick="clearSignature('directorSignaturePad${c.id}','directorSignature${c.id}')">Clear signature</button><span class="small muted">Sign using mouse, touch, or stylus.</span></div></div><div class="form-actions"><button class="btn" type="submit">Save review, payment & signature</button></div></form></section>`).join('') || '<section class="card"><p>No registrations have been submitted yet.</p></section>';
  res.send(page('Director portal',`<section class="hero"><div class="eyebrow">Camp administration</div><h1>Director portal</h1><p>Review parent registrations and signed consent forms, approve or request information, record payment status, and add the director’s signature.</p><div class="actions"><a class="btn" href="/director/logout">Sign out</a><a class="btn" href="/organizer">Activity updates</a></div></section>${overview}<section class="card"><h2>Find a registration</h2><div class="field"><label for="registrationSearch">Search child, parent, phone, email or status</label><input id="registrationSearch" type="search" placeholder="Type to filter registrations..."></div><p class="small muted" id="registrationCount">Showing ${campers.length} registrations</p></section><section class="card"><h2>Director checklist</h2><p>Confirm registration details, guardian consent, payment evidence and transport arrangements. Mark payment as received only after independently confirming it. This portal records payment status; it does not transfer or process money.</p><p class="warn">The attached PDF lists 100 ETB per day, while the website currently displays 1,000 ETB. Confirm the correct fee with the camp organizer before collecting money.</p></section>${cards}<section class="card"><div class="eyebrow">Parent communication</div><h2>Post an activity update</h2><p class="muted">Choose the camper and add a short attendance or activity note. It will appear in that camper's parent dashboard.</p><form method="post" action="/organizer/updates"><div class="formgrid"><div class="field"><label>Camper *</label><select name="camperId" required><option value="">Choose camper</option>${campers.map(c=>`<option value="${c.id}">#${c.id} — ${esc(c.child_name)} (parent: ${esc(c.parent_name)})</option>`).join('')}</select></div><div class="field"><label>Activity date *</label><input type="date" name="activityDate" required></div><div class="field"><label>Activity *</label><input name="activity" maxlength="120" required placeholder="e.g. Nature trail"></div><div class="field"><label>Attendance / status *</label><select name="attendance" required><option>Attended</option><option>Arrived</option><option>Checked out</option><option>Update</option></select></div><div class="field full"><label>Short note *</label><textarea name="note" maxlength="500" required rows="2" placeholder="Appropriate, non-sensitive update"></textarea></div></div><button class="btn" type="submit">Save activity update</button></form></section>${signatureScript}<script>const searchBox=document.getElementById('registrationSearch');if(searchBox){searchBox.addEventListener('input',()=>{const q=searchBox.value.toLowerCase().trim();let visible=0;document.querySelectorAll('.registration-card').forEach(card=>{const show=card.dataset.search.includes(q);card.hidden=!show;if(show)visible++;});document.getElementById('registrationCount').textContent='Showing '+visible+' of ${campers.length} registrations';});}${campers.map(c=>`setupSignature('directorSignaturePad${c.id}','directorSignature${c.id}');document.querySelector('form[action="/director/registration/${c.id}"]').addEventListener('submit',function(e){const status=this.querySelector('[name="directorStatus"]').value;const signature=document.getElementById('directorSignature${c.id}').value;const existing=${JSON.stringify(c.director_signature||'')};if(status==='Approved'&&!signature&&!existing){e.preventDefault();alert('Please add the director signature before approving.');}});`).join('')}</script>` ,{id:0}));
});
app.get('/director/export.csv',(req,res)=>{
  if(!req.session.organizer) return res.status(403).send('Director sign-in required');
  const rows=db.prepare('SELECT c.id,c.child_name,c.age,c.program,c.session_choice,c.status,c.director_status,c.payment_status,c.amount_received,c.payment_reference,c.created_at,p.name AS parent_name,p.phone AS parent_phone,p.email AS parent_email,c.emergency_contact,c.transport,c.pickup_area FROM campers c JOIN parents p ON p.id=c.parent_id ORDER BY c.id DESC').all();
  const cell=value=>'"'+String(value??'').replace(/"/g,'""')+'"';
  const headers=['Registration ID','Child name','Age','Program','Attendance preference','Registration status','Review status','Payment status','Amount received ETB','Payment reference','Submitted at','Parent name','Parent phone','Parent email','Emergency contact','Transport','Pickup area'];
  const csv=[headers,...rows.map(r=>[r.id,r.child_name,r.age,r.program,r.session_choice,r.status,r.director_status,r.payment_status,r.amount_received,r.payment_reference,r.created_at,r.parent_name,r.parent_phone,r.parent_email,r.emergency_contact,r.transport,r.pickup_area])].map(row=>row.map(cell).join(',')).join('\r\n');
  res.setHeader('Content-Type','text/csv; charset=utf-8');res.setHeader('Content-Disposition','attachment; filename=driftwood-camp-registrations.csv');res.send('\uFEFF'+csv);
});
app.post('/director/login',(req,res)=>{
  const configuredUsername=process.env.ADMIN_USERNAME;
  const configuredPassword=process.env.ADMIN_PASSWORD;
  if(!configuredUsername||!configuredPassword||String(req.body.adminUsername||'')!==configuredUsername||String(req.body.adminPassword||'')!==configuredPassword) return res.redirect('/director?error=1');
  req.session.regenerate(err=>{if(err)return res.status(500).send('Session error');req.session.organizer=true;res.redirect('/director');});
});
app.post('/director/registration/:id',(req,res)=>{
  if(!req.session.organizer) return res.status(403).send(page('Forbidden','<section class="card"><h1>Director sign-in required</h1><a class="btn" href="/director">Director login</a></section>'));
  const id=Number(req.params.id);
  const current=db.prepare('SELECT * FROM campers WHERE id=?').get(id);
  if(!current) return res.status(404).send(page('Not found','<section class="card"><h1>Registration not found</h1></section>'));
  const directorStatus=String(req.body.directorStatus||'Pending review');
  const allowedStatus=['Pending review','Approved','Needs information','Waiting list','Declined'];
  const paymentStatus=String(req.body.paymentStatus||'Not recorded');
  const allowedPayment=['Not recorded','Pending','Partially paid','Paid','Waived','Refunded'];
  const amount=String(req.body.amountReceived||'').trim();
  const paymentReference=String(req.body.paymentReference||'').trim().slice(0,100);
  const notes=String(req.body.directorNotes||'').trim().slice(0,1000);
  const directorName=String(req.body.directorName||'').trim().slice(0,120);
  const signature=String(req.body['directorSignature'+id]||'');
  if(!allowedStatus.includes(directorStatus)||!allowedPayment.includes(paymentStatus)|| (amount!==''&&(!Number.isFinite(Number(amount))||Number(amount)<0)) || (directorStatus==='Approved'&&!directorName)) return res.status(400).send(page('Invalid entry','<section class="card"><h1>Please check the status and amount.</h1><a class="btn" href="/director">Back to director portal</a></section>'));
  if(current.director_status==='Waiting list'&&directorStatus!=='Waiting list'&&db.prepare("SELECT COUNT(*) AS n FROM campers WHERE director_status!='Waiting list'").get().n>=40) return res.status(409).send(page('Camp capacity reached','<section class="card"><h1>Camp capacity is full</h1><p>Keep this camper on the waiting list until a place is available.</p><a class="btn" href="/director">Back to director portal</a></section>'));
  let savedSignature=current.director_signature||'';
  let signedAt=current.director_signed_at||'';
  if(signature){
    if(!validSignature(signature)) return res.status(400).send(page('Invalid signature','<section class="card"><h1>Could not read signature</h1><a class="btn" href="/director">Try again</a></section>'));
    savedSignature=signature; signedAt=new Date().toISOString();
  }
  if(directorStatus==='Approved'&&!savedSignature) return res.status(400).send(page('Signature required','<section class="card"><h1>Director signature required</h1><p>Sign the approval form before marking it approved.</p><a class="btn" href="/director">Back to director portal</a></section>'));
  db.prepare(`UPDATE campers SET director_status=?,payment_status=?,amount_received=?,payment_reference=?,director_notes=?,director_name=?,director_signature=?,director_signed_at=? WHERE id=?`).run(directorStatus,paymentStatus,amount,paymentReference,notes,directorName,savedSignature,signedAt,id);
  if (current.payment_status !== paymentStatus || String(current.amount_received) !== amount) {
    void notifyDirectorTelegram(`Driftwood Camp: payment record updated for registration #${id}. Status: ${paymentStatus}. Amount recorded: ${amount || 'not specified'} ETB. Updated: ${new Date().toISOString()}. Verify evidence in the secure Director Portal.`);
  }
  res.redirect('/director');
});
app.get('/director/logout',(req,res)=>{req.session.organizer=false;res.redirect('/director');});
app.get('/organizer',(req,res)=>res.redirect('/director'));
app.post('/organizer/login',(req,res)=>res.redirect('/director'));
app.post('/organizer/updates',(req,res)=>{
  if(!req.session.organizer) return res.status(403).send(page('Forbidden','<section class="card"><h1>Director sign-in required</h1><a class="btn" href="/director">Director login</a></section>'));
  const camperId=Number(req.body.camperId), activityDate=String(req.body.activityDate||''), activity=String(req.body.activity||'').trim(), note=String(req.body.note||'').trim(), attendance=String(req.body.attendance||'Update');
  const camper=db.prepare('SELECT id FROM campers WHERE id=?').get(camperId);
  if(!camper||!/^\d{4}-\d{2}-\d{2}$/.test(activityDate)||!activity||!note) return res.status(400).send(page('Check update','<section class="card"><h1>Please complete all update fields</h1><a class="btn" href="/director">Back to director portal</a></section>'));
  db.prepare('INSERT INTO activity_updates(camper_id,activity_date,activity,note,attendance) VALUES(?,?,?,?,?)').run(camperId,activityDate,activity,note,attendance);
  res.redirect('/director');
});
app.get('/logout',(req,res)=>req.session.destroy(()=>res.redirect('/')));
app.use((req,res)=>res.status(404).send(page('Page not found',`<section class="card"><h1>Page not found</h1><a class="btn" href="/">Go home</a></section>`)));
app.listen(PORT,()=>console.log(`Driftwood Camp running at http://localhost:${PORT}`));
