# Driftwood Camp — Node.js local website

This package includes a real local Node.js app with SQLite persistence, registration, parent login, a parent dashboard, separate signed agreement records, activity updates, camp games, and a map link for Gulele Botanic Garden.

## Requirements
- Node.js 18 or newer
- Internet connection for the first `npm install`

## Start on Windows, macOS, or Linux
1. Extract this ZIP.
2. Open Terminal / PowerShell in the extracted `driftwood-camp-node` folder.
3. Run:

   ```bash
   npm install
   npm start
   ```

4. Open http://localhost:3000. This is one website/app: parent registration, parent login, and director access are different pages (routes) within the same local server. Use the **Director portal** link in the site navigation, or open http://localhost:3000/director.

The app creates a local SQLite database in `data/driftwood.db` automatically.

## First use
- Open **Register** and register a parent and child.
- The parent account is created using the parent's email and password.
- Sign in at **Parent login** to see the child registration, selected program, transport request, signed agreements, payment/review status, and activity updates.
- Registration includes separate signatures for participation consent, outdoor activity risk acknowledgment, and emergency-care authorization. Photo/video permission is optional and separately recorded.
- For local testing, use an email you control and a strong password.

## Important before public launch
This is a starter app for local testing, not a production-ready child-services system. It stores parent/child information on the computer running Node.js. Before exposing it to the internet, configure HTTPS, a persistent production database, secure session storage, backups, access controls, rate limiting, email/password reset, consent and privacy notices, retention/deletion rules, and a reviewed safeguarding policy. Agreement text in this starter is draft wording, not legal advice; have it reviewed locally before collecting signatures. Finalize the photo/video agreement to match actual intended uses and local requirements. Do not use real children's personal data in an unprotected test deployment.

No payment is collected. The 1,000 ETB fee is displayed as supplied, but the fee basis, dates, venue permission, transport availability and pickup routes must be confirmed by the organizer. Map opens an external Google Maps search and does not confirm venue access.

## Organizer activity updates
Set a director username and password before starting the app:
- Windows PowerShell: `$env:ADMIN_USERNAME="director"; $env:ADMIN_PASSWORD="choose-a-long-private-password"; npm start`
- macOS/Linux: `ADMIN_USERNAME="director" ADMIN_PASSWORD="choose-a-long-private-password" npm start`

Open `/director` or `/organizer`, sign in with that username and password, and post attendance/activity updates for a registered camper. The relevant parent sees those updates in their dashboard. Do not share the organizer password.

## Parent activity view
The dashboard displays organizer-entered attendance and activity notes. It does **not** provide live GPS tracking, live video, or covert monitoring. Only enter appropriate, non-sensitive notes and share information with authorized guardians.

## Director registration overview
After signing in at `/director`, the dashboard reads real counts from the local SQLite database:
- Children within capacity out of 40, plus total registrations received
- Pending, approved, and waiting-list registrations
- Separate participation, outdoor-risk, and emergency-care signature checks for each child
- Optional photo/video choice, with a separate signature when permission is granted
- Reviewer name, review decision, follow-up notes, payment status, amount received, and receipt reference
- Parent/emergency contacts, transport and pickup details, and the latest recorded attendance check

New registrations are placed on the waiting list when 40 non-waitlisted registrations already exist. Attendance can be recorded in the director portal's activity update form using Arrived, Attended, or Checked out. The overview is database-backed, but it is not a substitute for a signed attendance procedure on camp day.

## Set your private director login
There is no default director username or password. Set both yourself before starting the app. Example values below are placeholders—replace them with private credentials:

**Windows PowerShell**
```powershell
$env:ADMIN_USERNAME="your-director-id"
$env:ADMIN_PASSWORD="use-a-long-private-password"
$env:SESSION_SECRET="replace-with-a-long-random-secret"
npm start
```

**macOS / Linux**
```bash
ADMIN_USERNAME="your-director-id" ADMIN_PASSWORD="use-a-long-private-password" SESSION_SECRET="replace-with-a-long-random-secret" npm start
```

Open `http://localhost:3000/director`. Keep these values private. The app uses a local SQLite database and a default in-memory session store suitable only for local testing. Before internet deployment, configure a production session store, HTTPS, rate limiting, backups, and appropriate child-data privacy and safeguarding processes.

## Director portal additions
The director dashboard also includes:
- Live totals for registrations, capacity, approvals, waiting list, recorded ETB payments, and complete required agreement sets.
- Search/filter across child name, parent name, phone, email, review status, payment status, and program.
- A director-only CSV export at `/director/export.csv` for registration and payment tracking. Keep exported files private because they contain family contact and child registration information.
- Existing per-child agreement review, parent signatures, director approval/signature, payment status/amount/reference, notes, and attendance/activity updates.


## Quick local director login setup

This download includes a private local `.env` file for testing. Start the server from this project folder with `npm install` and `npm start`, then sign in at `http://localhost:3000/director`. The temporary local username is `show77`; the password is printed separately in the download instructions provided with this ZIP. Keep `.env` private: it is excluded from Git by `.gitignore`.

## Render deployment: required environment variables

A local `.env` file is **not uploaded to Render** when deploying from GitHub. In Render, open the Web Service → **Environment** → **Add Environment Variable**, and add `ADMIN_USERNAME`, `ADMIN_PASSWORD`, and `SESSION_SECRET` (use your own new strong values). Save changes and redeploy/restart. Also add Telegram variables only if Telegram alerts are enabled. Never commit `.env` or paste secrets into GitHub.

## Configure the director login
The director credentials are deliberately not written into the website source or ZIP. Set them in the terminal before starting the app. Use the username you chose and enter your private password locally (do not paste it into public code or share it).

**Windows PowerShell**
```powershell
$env:ADMIN_USERNAME='show77'
$env:ADMIN_PASSWORD='123abc@$'
$env:SESSION_SECRET='REPLACE_WITH_A_LONG_RANDOM_SECRET'
npm start
```

**macOS / Linux**
```bash
ADMIN_USERNAME='show77' ADMIN_PASSWORD='123abc@$' SESSION_SECRET='REPLACE_WITH_A_LONG_RANDOM_SECRET' npm start
```

Then open `http://localhost:3000/director`. The director login is configured with the username and password above. Since this password has been shared in a chat and is relatively short, change it to a new, unique password before using the portal with real family or child information. Keep the session secret private too.


## Director login troubleshooting (updated)
The project ZIP includes a local `.env` configuration file, and the server now loads it automatically. Start the app with `npm start`, then sign in at `http://localhost:3000/director` using the director credentials you configured in `.env`. If you change the credentials, edit `.env` and fully stop/restart the Node.js server. Do not upload `.env` to public hosting or share it. Replace the temporary password and session secret before using real child or family data.

## Payment instructions and receipt upload

The registration form displays the camp's Dashen Bank account (5516105727021) and Telebirr number (0935347799). Parents can select Dashen Bank, Telebirr, or cash and optionally upload a PNG/JPG/WEBP payment receipt image (maximum 2 MB). The receipt is visible to the director in the registration record. Uploading a receipt does not automatically mark a payment as paid; the director must verify the transfer and update the payment status.

Before public launch, verify the account holder name and payment details with the camp organizer, use HTTPS, and protect backups because registration and receipt data are private.

## Optional Telegram director alerts (privacy-preserving)

The app can send director notifications when a registration is received and when its payment status/amount is updated. Alerts contain only the registration reference, event timestamp, and operational payment status. They do **not** send children's or parents' names, phone numbers, email addresses, emergency contacts, signatures, notes, or receipt images. Open the authenticated Director Portal to review records and receipt evidence.

1. The Telegram bot token previously pasted into chat must be revoked immediately in Telegram's **@BotFather** using `/revoke`, then select the bot. Do not reuse the exposed token.
2. Create a new token only after revocation. Never put it in website source code, GitHub, or a ZIP file.
3. On Render, open your Web Service → **Environment** and add `TELEGRAM_BOT_TOKEN` (new token) and `TELEGRAM_CHAT_ID` (your private chat ID). Also configure `ADMIN_USERNAME`, `ADMIN_PASSWORD`, and a long random `SESSION_SECRET` there.
4. For local development, copy `.env.example` to `.env`, fill in the values privately, and ensure `.env` is not committed to GitHub.
5. Restart/redeploy the service. Send `/start` to your bot from the Telegram account that should receive alerts.

Do not forward child records or payment receipt images to Telegram. Use the password-protected Director Portal for sensitive records and configure persistent encrypted storage and backups before collecting real information.

## Telegram director notifications

The server can send Telegram text alerts for new registrations and payment-status changes.
For privacy, it does **not** send child/guardian details, signatures, notes, or payment receipt images to Telegram. Receipt images remain accessible only in the authenticated Director Portal.

1. If a bot token has ever been pasted into a chat or public place, revoke it with @BotFather and generate a new token.
2. Set `TELEGRAM_BOT_TOKEN` to the newly generated token and `TELEGRAM_CHAT_ID` to your private chat ID in the server's private `.env` file (local) or hosting provider's Environment settings (Render).
3. Send `/start` to your bot from the target Telegram account.
4. Restart/redeploy the server. Never commit `.env` to GitHub; `.gitignore` excludes it.

Example environment variables:

```env
TELEGRAM_BOT_TOKEN=your_new_private_token
TELEGRAM_CHAT_ID=your_private_chat_id
```
